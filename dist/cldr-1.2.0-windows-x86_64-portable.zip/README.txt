CLDR v1.2.0 - portable Windows x86_64 build
(c) 2026 Dr. Sohil Momin - MIT license, attribution required

Run cldr.exe directly - no installer needed.
Calculator now supports + - * / % ^ ( ) and unary minus.
See docs/SETUP_GUIDE.md and scripts/install-shortcut.ps1 for tray/shortcut setup.
